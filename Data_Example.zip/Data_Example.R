###############################################################################
#
#  This is the R code to reproduce the results
#
################################################################################

library(Matrix)
library(HCD)
library(tm)
library(igraph)
source('Methods.R')
source('Helper_functions.R')


####################
# Load data
####################
A = as.matrix(read.table("data/paperCitAdj.txt", header=F)) ## paper cite paper
A = A | t(A) + 0 # symmetrized
A = Matrix(A)  # transforms to sparse matrix

absk = read.table("data/paperList_Abstracts_Keyword.txt", sep = ",",
                  colClass = c("character","integer", "character", "character"), 
                  header = T) # paper - abstract - keywords


# largest connected component
g = graph_from_adjacency_matrix(A, mode='undirected', diag=FALSE)
gc = components(g)
largested_connected_id = gc$membership == which.max(gc$csize)

A.connect = A[largested_connected_id,largested_connected_id]
rm(A)

####################
# Process text data
####################
prep_abstract = function(x){
  temp = MC_tokenizer(x)
  temp = tolower(temp)
  temp = paste(temp, collapse=' ')
  temp
}

abs_list = lapply(absk$abstracts, prep_abstract)

vc <- VCorpus( VectorSource(abs_list[largested_connected_id]) ) # just change the vector of strings to corpus
ctrl <- list(removePunctuation = list(preserve_intra_word_dashes = TRUE)
             , weighting = function(x) weightTfIdf(x, normalize = TRUE)
             , stopwords = TRUE
             , removeNumbers = TRUE
             , stemming = TRUE
             #, bounds = list(global= c(10,0.9*sum(largested_connected_id)))   # remove low-frequency/high frequency words
             #, wordLengths = c(3, 50) # remove short words like 'a' 
)

tdm = TermDocumentMatrix(vc, control =  ctrl)  ## term - ducoment matrix
tdm_rm_sparse = removeSparseTerms(tdm, sparse=0.99)
dim(tdm_rm_sparse)
tdm_rm_sparse

terms = tdm_rm_sparse$dimnames$Terms
print ( sprintf( "after initial cleaning: %s words remains in %s docuemnts",
                 dim(tdm_rm_sparse)[1], dim(tdm_rm_sparse)[2], '\n') )

# Paper-level cosine similarity
temp_tdm_rm_sparse = as.matrix(tdm_rm_sparse)
temp_tdm_rm_sparse = t(temp_tdm_rm_sparse) / sqrt( apply(temp_tdm_rm_sparse^2, 2, sum) )
paper.cos.sim = temp_tdm_rm_sparse %*% t(temp_tdm_rm_sparse)

# paper.cos.sim = cor(temp_tdm_rm_sparse)
## This is used to produce the table in the paper

# Entries with no abstract
no.abs.id = c(182, 351, 409, 661, 1518, 1586, 1686, 2166)
paper.cos.sim[no.abs.id,] = NA
paper.cos.sim[,no.abs.id] = NA

####################
# Analysis
####################
HCDplot <- function(hcd,mode="community",labels=NULL,main=NULL,label.cex=1){
  if(mode=="community"){
    S <- hcd$comm.bin.sim.mat
    if(nrow(S)<=2){
      print("Too few clusters to plot!")
    }else{
      dis <- max(S)+1-S
      hc <- hclust(d=as.dist(dis),method="complete")
      par(cex=label.cex)
      plot(hc,main=main,yaxt="n",ann=FALSE,labels=labels)
      par(cex=1)
      title(main=main)
      
    }
  }else{
    S <- HCD.result$node.bin.sim.mat
    dis <- max(S)+1-S
    diag(dis) <- 0
    hc <- hclust(d=as.dist(dis),method="complete")
    par(cex=label.cex)
    plot(hc,main=main,yaxt="n",ann=FALSE,labels=labels)
    par(cex=1)
    title(main=main)
  }
  
}

cor.mat.node.average = function(id, HCD.obj, plot=FALSE, A=NULL, main=''){
  temp = paper.cos.sim[id,id]
  diag(temp) = NA
  CS = matrix(NA, HCD.obj$ncl, HCD.obj$ncl)
  HCD.sim.mat.temp = HCD.obj$comm.bin.sim.mat
  for(i in 1:HCD.obj$ncl){
    idx1 = i==HCD.obj$labels
    for(j in 1:HCD.obj$ncl){
      idx2 = j==HCD.obj$labels
      CS[i,j] = mean(temp[idx1, idx2], na.rm=TRUE)
    }
  }
  if(plot==3){
    ACP = matrix(NA, HCD.obj$ncl, HCD.obj$ncl)
    for(i in 1:HCD.obj$ncl){
      idx1 = i==HCD.obj$labels
      for(j in 1:HCD.obj$ncl){
        idx2 = j==HCD.obj$labels
        ACP[i,j] = mean(A[idx1, idx2], na.rm=TRUE)
      }
    }
    par(mfrow=c(1,3))
    par(mar=c(0.5,0.5,0.5,0.5))
    image(ACP[,ncol(ACP):1], main=main, xaxt='n', yaxt='n', col=grey.colors(20, rev=TRUE))
    image(CS[,ncol(CS):1], main=main, xaxt='n', yaxt='n', col=grey.colors(20, rev=TRUE))
    image(log(HCD.sim.mat.temp[,ncol(HCD.sim.mat.temp):1]+10), xaxt='n', yaxt='n', col=grey.colors(20, rev=TRUE))
    # image(HCD.sim.mat.temp[,ncol(HCD.sim.mat.temp):1], xaxt='n', yaxt='n', col=grey.colors(20, rev=TRUE))
    print(mean(diag(CS)))
  }else if(plot){
    par(mfrow=c(1,2))
    par(mar=c(0.5,0.5,0.5,0.5))
    image(CS[,ncol(CS):1], main=main, xaxt='n', yaxt='n', col=grey.colors(20, rev=TRUE))
    image(log(HCD.sim.mat.temp[,ncol(HCD.sim.mat.temp):1]+10), xaxt='n', yaxt='n', col=grey.colors(20, rev=TRUE))
    # image(HCD.sim.mat.temp[,ncol(HCD.sim.mat.temp):1], xaxt='n', yaxt='n', col=grey.colors(20, rev=TRUE))
    print(mean(diag(CS)))
  }
  par(mfrow=c(1,1))
  cor(as.numeric(CS[upper.tri(CS,diag=TRUE)]), log(HCD.sim.mat.temp[upper.tri(HCD.sim.mat.temp,diag=TRUE)]), use='complete.obs', method='spearman')
}


k.core.id.3 = k_core(A.connect, k=3)
k.core.id = k_core(A.connect, k=4)
A.4core = A.connect[k.core.id,k.core.id]
A.3core = A.connect[k.core.id.3,k.core.id.3]

r = 13
Ours.score.1 = Ours.ER.function(A.connect, r)
Ours.score.2 = Ours.Config.function(A.connect, r)

degree = apply(A.connect, 1, sum)
pagerank.score = pagerank(A.connect)
ev.score = abs( irlba(A.connect, maxit=10000)$u[,1] )
local.cc.score = transitivity(graph.adjacency(A.connect, mode='undirected', diag=FALSE), type='localundirected', isolates='zero')

####################
# Thresholding
####################
nc = c(635, 1103)

retval.comm = matrix(NA, 7, length(nc))
colnames(retval.comm) = nc
rownames(retval.comm) = c('Degree', 'k-core', 'PageRank', 'EigenVec', 'Local CC', 'Ours (ER)', 'Ours (Config)')

HCD.3core = HCD(A.3core, method='SS', reg=TRUE, notree=FALSE, n.min=round(1103/r))
HCD.4core = HCD(A.4core, method='SS', reg=TRUE, notree=FALSE, n.min=round(635/r))

retval.comm[2,1] = cor.mat.node.average(k.core.id, HCD.4core)
retval.comm[2,2] = cor.mat.node.average(k.core.id.3, HCD.3core)

for(j in 1:ncol(retval.comm)){
  print(j)
  # Select sub-network
  select.size = nc[j]
  
  ER.id = Ours.score.1 > quantile(Ours.score.1, 1-select.size/nrow(A.connect))
  A.ER = A.connect[ER.id,ER.id]
  
  Config.id = Ours.score.2 > quantile(Ours.score.2, 1-select.size/nrow(A.connect))
  A.config = A.connect[Config.id,Config.id]
  
  degree.id1 = degree >= quantile(degree, 1-select.size/nrow(A.connect))
  degree.id2 = degree > quantile(degree, 1-select.size/nrow(A.connect))
  if( abs( sum(degree.id1)-select.size ) < abs( sum(degree.id2)-select.size ) ){
    degree.id = degree.id1
  }else{
    degree.id = degree.id2
  }
  A.degree = A.connect[degree.id,degree.id]
  
  ev.id = ev.score > quantile(ev.score, 1-select.size/nrow(A.connect))
  A.ev = A.connect[ev.id,ev.id]
  
  pagerank.id = pagerank.score > quantile(pagerank.score, 1-select.size/nrow(A.connect))
  A.pagerank = A.connect[pagerank.id,pagerank.id]
  
  local.cc.id = local.cc.score > quantile(local.cc.score, 1-select.size/nrow(A.connect))
  A.local.cc = A.connect[local.cc.id,local.cc.id]
  
  # Fit HCD
  HCD.ER = HCD(A.ER, method='SS', reg=TRUE, notree=FALSE, n.min=round(select.size/r))
  HCD.Config = HCD(A.config, method='SS', reg=TRUE, notree=FALSE, n.min=round(select.size/r))
  HCD.degree = HCD(A.degree, method='SS', reg=TRUE, notree=FALSE, n.min=round(select.size/r))
  HCD.ev = HCD(A.ev, method='SS', reg=TRUE, notree=FALSE, n.min=round(select.size/r))
  HCD.pagerank = HCD(A.pagerank, method='SS', reg=TRUE, notree=FALSE, n.min=round(select.size/r))
  HCD.local = HCD(A.local.cc, method='SS', reg=TRUE, notree=FALSE, n.min=round(select.size/r))
  
  # Correlation
  retval.comm[1,j] = cor.mat.node.average(degree.id, HCD.degree)
  retval.comm[3,j] = cor.mat.node.average(pagerank.id, HCD.pagerank)
  retval.comm[4,j] = cor.mat.node.average(ev.id, HCD.ev)
  retval.comm[5,j] = cor.mat.node.average(local.cc.id, HCD.local)
  retval.comm[6,j] = cor.mat.node.average(ER.id, HCD.ER)
  retval.comm[7,j] = cor.mat.node.average(Config.id, HCD.Config)
  
}


# Table
round(retval.comm,3)


HCD.all = HCD(A.connect, method='SS', reg=TRUE, notree=FALSE, n.min=round(nrow(A.connect)/r))
cor.mat.node.average(rep(TRUE,nrow(A.connect)), HCD.all)


####################
# Plot cores
####################

ER.id = Ours.score.1 > quantile(Ours.score.1, 1-635/nrow(A.connect))
A.ER.635 = A.connect[ER.id,ER.id]
HCD.ER.635 = HCD(A.ER.635, method='SS', reg=TRUE, notree=FALSE, n.min=round(635/r))
ER.id = Ours.score.1 > quantile(Ours.score.1, 1-1103/nrow(A.connect))
A.ER.1103 = A.connect[ER.id,ER.id]
HCD.ER.1103 = HCD(A.ER.1103, method='SS', reg=TRUE, notree=FALSE, n.min=round(1103/r))

Config.id = Ours.score.2 > quantile(Ours.score.2, 1-635/nrow(A.connect))
A.config.635 = A.connect[Config.id,Config.id]
HCD.Config.635 = HCD(A.config.635, method='SS', reg=TRUE, notree=FALSE, n.min=round(635/r))
Config.id = Ours.score.2 > quantile(Ours.score.2, 1-1103/nrow(A.connect))
A.config.1103 = A.connect[Config.id,Config.id]
HCD.Config.1103 = HCD(A.config.1103, method='SS', reg=TRUE, notree=FALSE, n.min=round(1103/r))


HCDplot(HCD.ER.635)
#HCDplot(HCD.ER.1103)
HCDplot(HCD.Config.635)
#HCDplot(HCD.Config.1103)

colours <- c("red","yellow","green","blue","pink",'brown',
             "cyan","grey","orange", 'purple','black')


g.all = graph.adjacency(A.connect, mode='undirected')
ER.id.635 = Ours.score.1 > quantile(Ours.score.1, 1-635/nrow(A.connect))
g.ER.635 = graph.adjacency(A.connect[ER.id.635,ER.id.635], mode='undirected')
ER.id.1103 = Ours.score.1 > quantile(Ours.score.1, 1-1103/nrow(A.connect))
g.ER.1103 = graph.adjacency(A.connect[ER.id.1103,ER.id.1103], mode='undirected')
Config.id.635 = Ours.score.2 > quantile(Ours.score.2, 1-635/nrow(A.connect))
g.Config.635 = graph.adjacency(A.connect[Config.id.635,Config.id.635], mode='undirected')
Config.id.1103 = Ours.score.2 > quantile(Ours.score.2, 1-1103/nrow(A.connect))
g.Config.1103 = graph.adjacency(A.connect[Config.id.1103,Config.id.1103], mode='undirected')


lo = layout.lgl(g.all)
lo = apply(lo, 2, function(x){x = x-mean(x); x=x/max(x)})

pdf('All.pdf', width=4.22, height=3.77)
par(mar = c(0.3, 0.3, 0.3, 0.3))
plot(g.all,edge.width=0.8, vertex.size=1.5*(degree(g.all)^(1/3)), vertex.label=NA,layout=lo,rescale=TRUE)
dev.off()

pdf('ER635.pdf', width=4.22, height=3.77)
par(mar = c(0.3, 0.3, 0.3, 0.3))
plot(g.ER.635,edge.width=0.8,vertex.size=1.5*(degree(g.ER.635)^(1/3)), vertex.label=NA,layout=lo[ER.id.635,],rescale=TRUE)
dev.off()
pdf('ER1103.pdf', width=4.22, height=3.77)
par(mar = c(0.3, 0.3, 0.3, 0.3))
plot(g.ER.1103,edge.width=0.8,vertex.size=1.5*(degree(g.ER.1103)^(1/3)), vertex.label=NA,layout=lo[ER.id.1103,],rescale=TRUE)
dev.off()

pdf('Config635.pdf', width=4.22, height=3.77)
par(mar = c(0.3, 0.3, 0.3, 0.3))
plot(g.Config.635,edge.width=0.8,vertex.size=1.5*(degree(g.Config.635)^(1/3)), vertex.label=NA,layout=lo[Config.id.635,],rescale=TRUE)
dev.off()
pdf('Config1103.pdf', width=4.22, height=3.77)
par(mar = c(0.3, 0.3, 0.3, 0.3))
plot(g.Config.1103,edge.width=0.8,vertex.size=1.5*(degree(g.Config.1103)^(1/3)), vertex.label=NA,layout=lo[Config.id.1103,],rescale=TRUE)
dev.off()





####################

color.community = function(A, lo.temp, HCD.obj, colours){
  g = graph.adjacency(A, mode="undirected", diag=FALSE)
  V(g)$color = colours[HCD.obj$labels]
  par(mfrow=c(1,2))
  par(mar=c(2,1,2,2))
  HCDplot(HCD.obj)
  par(mar=c(0.5,0,0.5,0.5))
  plot(g, edge.width=0.3, vertex.size=1.5*(degree(g)^(1/3)), vertex.label=NA, layout=lo.temp, rescale=TRUE)
  unique.labs = sort( unique(HCD.obj$labels) )
  legend('topright', inset=c(-0.036,0), legend=unique.labs, col=colours[unique.labs], pch=19, cex=0.65, bty="n", bg='transparent')
  legend('topright', inset=c(-0.036,0), legend=unique.labs, col=1, pch=1, cex=0.65, bty="n", bg='transparent')
}


pdf('ER_hierarchy.pdf', width=7.55, height=4.71)
color.community(A.ER.635, layout.auto(g.ER.635), HCD.ER.635, colours)
dev.off()
pdf('Config_hierarchy.pdf', width=7.55, height=4.71)
color.community(A.config.635, layout.auto(g.Config.635), HCD.Config.635, colours)
dev.off()

pdf('Config_hierarchy2.pdf', width=7.55, height=4.71)
color.community(A.config.635, lo[Config.id.635,], HCD.Config.635, colours)
dev.off()



# Most frequent keywords
clu.vec = rep(NA, length(abs_list))
clu.vec[largested_connected_id][Config.id.635] = HCD.Config.635$labels

a = cbind(absk$keywords, clu.vec)
a = a[!is.na(a[,2]),]
a = data.frame(a)
a$V1 = as.character(a$V1)
a$clu.vec = as.numeric(as.character(a$clu.vec))


retval = list()
slist = rep('',length(table(a$clu.vec)))
for(i in 1:length(table(a$clu.vec))){
  kw.pool = unlist(strsplit(a$V1[a$clu.vec == i], ';'))
  
  retval[[i]] = sort(table(kw.pool) / sum(a$clu.vec == i), decreasing=TRUE)
  
  temp = paste(names(retval[[i]]), ' ($', round(retval[[i]]*100,2), '\\%$)', sep='')
  slist[i] = paste(temp, collapse=', ')
}

write.table(slist, 'Cluster_Keywords.txt', row.names = F, quote = F)

